#!/usr/bin/env python3
"""Inspect or repair Coppola's local tools; never changes account connections."""
import argparse, hashlib, json, os, platform, shutil, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
HF_VERSION = '0.8.63'

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()

def run(args):
    return subprocess.run(args, check=True, capture_output=True, text=True, timeout=1800)

def inspect(hyperframes=False):
    bins = {x: shutil.which(x) for x in ('ffmpeg','ffprobe','whisper-cli','rclone','brew','node','npm')}
    failures = {}
    for name, flag in [('ffmpeg','-version'),('ffprobe','-version'),('whisper-cli','--help'),('rclone','version')]:
        if bins[name]:
            try: run([bins[name],flag])
            except Exception: failures[name] = 'Installed binary did not execute successfully'
    subtitles = False
    if bins['ffmpeg'] and 'ffmpeg' not in failures:
        subtitles = ' subtitles ' in run([bins['ffmpeg'],'-hide_banner','-filters']).stdout
    info = json.loads((ROOT/'models/PROVENANCE.json').read_text())
    model = ROOT/'models'/info['file']
    model_ok = model.is_file() and digest(model)==info['sha256']
    missing = list(dict.fromkeys(formula for tool,formula in [('ffmpeg','ffmpeg'),('ffprobe','ffmpeg'),('whisper-cli','whisper.cpp'),('rclone','rclone')] if not bins[tool]))
    node_ok=False
    if bins['node']:
        try:node_ok=int(run([bins['node'],'--version']).stdout.strip().lstrip('v').split('.')[0])>=22
        except Exception:failures['node']='Node version could not be checked'
    hf=ROOT/'runtime/node_modules/hyperframes/package.json';hf_ok=False
    if hf.is_file():hf_ok=json.loads(hf.read_text()).get('version')==HF_VERSION
    if hyperframes and (not bins['node'] or not bins['npm']):missing.append('node')
    return {'platform':platform.system(),'binaries':bins,'binary_failures':failures,'missing_packages':missing,'model_verified':model_ok,'burned_captions_available':subtitles,'repair_supported':bool(bins['brew']),'hyperframes':{'requested':hyperframes,'pinned_version':HF_VERSION,'local_package_present':hf_ok,'node_22_or_newer':node_ok,'ready_for_doctor':hf_ok and node_ok,'doctor_and_render':'not implied; run actual doctor/check/render'}, 'execution_test':'pending; presence is not a completed media job','account_setup':'separate; no credentials copied'}

def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['check','repair']);p.add_argument('--allow-install',action='store_true');p.add_argument('--hyperframes',action='store_true');a=p.parse_args()
    before=inspect(a.hyperframes)
    if a.action=='repair':
        if not a.allow_install: raise ValueError('Repair requires authorised software/model installation and --allow-install')
        if before['binary_failures']: raise ValueError('An existing tool failed; inspect it before replacing an installation')
        if before['missing_packages']:
            if not before['repair_supported']: raise ValueError('Homebrew is unavailable. Use instructions/INSTALL.md for this platform; no installation attempted.')
            env=dict(os.environ,HOMEBREW_NO_AUTO_UPDATE='1')
            subprocess.run([before['binaries']['brew'],'install',*before['missing_packages']],check=True,env=env,timeout=1800)
        if not before['model_verified']:
            run([sys.executable,str(ROOT/'bootstrap.py'),'model'])
        if a.hyperframes:
            current=inspect(True)
            if not current['hyperframes']['node_22_or_newer']:raise ValueError('Node 22+ is required; preserve existing Node and select a supported runtime before continuing')
            if not current['hyperframes']['local_package_present']:
                runtime=ROOT/'runtime';runtime.mkdir(exist_ok=True)
                if (runtime/'package.json').exists() and json.loads((runtime/'package.json').read_text()).get('dependencies')!={'hyperframes':HF_VERSION}:raise ValueError('Existing runtime differs; preserve it and review before replacing')
                (runtime/'package.json').write_text(json.dumps({'name':'coppola-media-runtime','private':True,'dependencies':{'hyperframes':HF_VERSION}},indent=2))
                subprocess.run([current['binaries']['npm'],'install','--prefix',str(runtime),'--ignore-scripts','--no-audit','--no-fund'],check=True,timeout=1800)
    report=inspect(a.hyperframes);(ROOT/'state').mkdir(exist_ok=True)
    (ROOT/'state/coppola-tool-readiness.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    ready=not report['missing_packages'] and not report['binary_failures'] and report['model_verified']
    return 0 if ready and (not a.hyperframes or report['hyperframes']['ready_for_doctor']) else 2

if __name__=='__main__':
    try: sys.exit(main())
    except Exception as e: print(json.dumps({'error':str(e)}),file=sys.stderr);sys.exit(1)
