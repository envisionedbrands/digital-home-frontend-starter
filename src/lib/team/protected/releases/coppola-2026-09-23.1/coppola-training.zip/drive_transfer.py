#!/usr/bin/env python3
"""Scoped large-media transfer through the owner's authenticated rclone Drive remote.
No credentials are bundled or accepted in this configuration. Configure rclone through
its native account sign-in first; runtime instructions verify the account and scope.
"""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def checksum(path):
 h=hashlib.md5()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()

def config(path):
 c=json.loads(Path(path).read_text())
 if c.get('account_verified') is not True or not c.get('account_email') or not c.get('account_checked_at'):raise ValueError('Verify this client account before media access')
 if not c.get('remote') or not c['remote'].replace('-','').replace('_','').isalnum():raise ValueError('Use a verified rclone remote name')
 if not Path(c.get('rclone_config','')).expanduser().is_file():raise ValueError('Native Drive sign-in/configuration is missing on this computer')
 for k in ['raw','review']:
  if not c.get('folders',{}).get(k):raise ValueError('Missing verified '+k+' folder ID')
 if c['folders']['raw']==c['folders']['review']:raise ValueError('Raw and Review must be different folders')
 return c

def run(c,folder,args):
 binary=shutil.which('rclone')
 if not binary:raise ValueError('rclone is not installed; use its official setup before large media transfers')
 p=subprocess.run([binary,'--config',str(Path(c['rclone_config']).expanduser()),'--drive-root-folder-id',c['folders'][folder],'--retries','2','--low-level-retries','2','--contimeout','20s','--timeout','300s']+args,capture_output=True,text=True,timeout=1800)
 if p.returncode:raise ValueError('Direct Drive transfer failed; inspect the native connection without posting credentials or provider debug logs')
 return p.stdout

def safe_name(name):
 if not name or name in ['.','..'] or '/' in name or '\\' in name or any(ord(c)<32 for c in name):raise ValueError('Use one exact filename from the verified folder')
 return name

def listing(c):return json.loads(run(c,'raw',['lsjson',c['remote']+':','--files-only','--hash','--max-depth','1']))

def upload(c,path):
 p=Path(path).resolve(strict=True)
 if not p.is_relative_to(ROOT/'video/results'):raise ValueError('Upload only this client workspace video/results artifacts')
 name=safe_name(p.name)
 run(c,'review',['copyto',str(p),c['remote']+':'+name,'--immutable','--checksum'])
 m=json.loads(run(c,'review',['lsjson',c['remote']+':'+name,'--stat','--hash']))
 if m.get('Size')!=p.stat().st_size or m.get('Hashes',{}).get('md5')!=checksum(p):raise ValueError('Uploaded output could not be verified')
 return {'id':m['ID'],'name':name,'size':m['Size'],'md5':m['Hashes']['md5'],'url':'https://drive.google.com/file/d/'+m['ID']+'/view','phone_playback':'not yet verified'}

def download(c,name):
 safe_name(name);rows=[r for r in listing(c) if r.get('Name')==name]
 if len(rows)!=1:raise ValueError('Filename is absent or ambiguous; select a unique source')
 m=rows[0]
 if not m.get('Hashes',{}).get('md5'):raise ValueError('Source has no content hash yet; wait for completed upload')
 dest=ROOT/'video/inbox'/name;dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():
  if dest.stat().st_size==m['Size'] and checksum(dest)==m['Hashes']['md5']:return {'path':str(dest),'id':m['ID'],'reused':True}
  raise ValueError('Different source already exists locally; preserve it and use a new source filename')
 partial=dest.with_name(dest.name+'.partial')
 run(c,'raw',['copyto',c['remote']+':'+name,str(partial),'--immutable','--checksum'])
 after=[r for r in listing(c) if r.get('ID')==m['ID']]
 if len(after)!=1 or after[0].get('Hashes',{}).get('md5')!=m['Hashes']['md5']:raise ValueError('Source changed during download; preserve partial and retry after upload stabilises')
 if partial.stat().st_size!=m['Size'] or checksum(partial)!=m['Hashes']['md5']:raise ValueError('Downloaded source did not match its Drive checksum')
 # Exclusive destination creation avoids overwriting a concurrent job.
 with partial.open('rb') as source,dest.open('xb') as target:shutil.copyfileobj(source,target,1048576)
 partial.unlink();return {'path':str(dest),'id':m['ID'],'md5':m['Hashes']['md5'],'reused':False}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--config',required=True);s=p.add_subparsers(dest='action',required=True);s.add_parser('list');s.add_parser('download').add_argument('name');s.add_parser('upload').add_argument('path');a=p.parse_args()
 try:
  c=config(a.config);result=listing(c) if a.action=='list' else download(c,a.name) if a.action=='download' else upload(c,a.path);print(json.dumps(result,indent=2))
 except Exception as e:p.exit(1,str(e)+'\n')
