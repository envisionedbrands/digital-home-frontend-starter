#!/usr/bin/env python3
"""Verified local CPU transcription; generates draft TXT/SRT, not speaker identification."""
import shutil
import argparse,json,subprocess,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
MODEL=ROOT/'models/ggml-small.en-q5_1.bin'
def main(source,destination):
 source=Path(source).resolve(strict=True);dest=Path(destination).resolve()
 if not any(dest.is_relative_to((ROOT/p).resolve()) for p in ['calls/results','video/results']):raise ValueError('Destination must be inside this client results workspace')
 if dest.exists():raise ValueError('Use a new destination; transcripts are never overwritten')
 if not MODEL.is_file():raise ValueError('Local speech model unavailable; verify the connection or accept a supplied transcript')
 with tempfile.TemporaryDirectory(prefix='captivation-asr-') as tmp:
  tmp=Path(tmp);wav=tmp/'source.wav';prefix=tmp/'transcript'
  subprocess.run([shutil.which('ffmpeg') or 'ffmpeg','-v','error','-nostdin','-i',str(source),'-vn','-ar','16000','-ac','1','-c:a','pcm_s16le',str(wav)],check=True,capture_output=True,timeout=600)
  if wav.stat().st_size<1000:raise ValueError('No usable audio extracted')
  subprocess.run([shutil.which('whisper-cli') or 'whisper-cli','-ng','-m',str(MODEL),'-f',str(wav),'-l','en','-otxt','-osrt','-of',str(prefix),'-t','4'],check=True,capture_output=True,timeout=1800)
  text=prefix.with_suffix('.txt');srt=prefix.with_suffix('.srt')
  if not text.is_file() or not text.read_text().strip() or not srt.is_file():raise ValueError('Transcription produced no usable output')
  dest.mkdir(parents=True,exist_ok=False)
  for p in [text,srt]:shutil.copy2(p,dest/p.name)
  meta={'source':str(source),'engine':'whisper.cpp CPU','model':MODEL.name,'language':'en','speaker_identification':False,'status':'machine draft; review names, numbers and timings before use'}
  (dest/'provenance.json').write_text(json.dumps(meta,indent=2))
 return {'text':str(dest/'transcript.txt'),'captions':str(dest/'transcript.srt'),'status':'draft'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('destination');a=p.parse_args()
 try:print(json.dumps(main(a.source,a.destination),indent=2))
 except Exception as e:p.exit(1,str(e)+'\n')
