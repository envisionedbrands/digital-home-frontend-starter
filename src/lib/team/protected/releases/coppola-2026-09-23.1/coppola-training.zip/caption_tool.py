#!/usr/bin/env python3
"""Burn reviewed SRT subtitles into a new preview, preserving the source."""
import argparse, hashlib, json, re, shutil, subprocess, tempfile
from pathlib import Path
from video_tool import probe
ROOT=Path(__file__).resolve().parent
def run(args):return subprocess.run(args,check=True,capture_output=True,text=True,timeout=900)
def burn(source,captions,output):
    source=Path(source).resolve(strict=True);captions=Path(captions).resolve(strict=True);output=Path(output).resolve()
    if not output.is_relative_to((ROOT/'video/results').resolve()) or output.suffix.lower()!='.mp4':raise ValueError('Choose a new MP4 inside video/results')
    if output.exists() or output==source:raise ValueError('Existing files are preserved')
    text=captions.read_text(encoding='utf-8-sig')
    cues=re.findall(r'(\d{2}):(\d{2}):(\d{2}),(\d{3}) --> (\d{2}):(\d{2}):(\d{2}),(\d{3})',text)
    if not cues or not re.search(r'-->[^\n]*\n[^\S\n]*\S',text):raise ValueError('Nonempty, timecoded SRT required')
    info=probe(source);prev=0
    for cue in cues:
        a,b=[int(cue[i])*3600+int(cue[i+1])*60+int(cue[i+2])+int(cue[i+3])/1000 for i in (0,4)]
        if not 0<=prev<=a<b<=info['duration']+.3:raise ValueError('Caption timings must fit this exact video; transcribe the cut preview before captioning')
        prev=b
    ffmpeg=shutil.which('ffmpeg') or 'ffmpeg';output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='coppola-captions-') as tmp:
        tmp=Path(tmp);shutil.copy2(captions,tmp/'captions.srt');candidate=tmp/'captioned.mp4'
        # Fixed local subtitle filename avoids injecting untrusted file paths into a filter expression.
        subprocess.run([ffmpeg,'-v','error','-nostdin','-i',str(source),'-vf',"subtitles=captions.srt:force_style='FontName=Arial,FontSize=22,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=2,Shadow=0,MarginV=24'",'-map','0:v:0','-map','0:a?','-c:v','libx264','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-movflags','+faststart',str(candidate)],cwd=tmp,check=True,capture_output=True,timeout=900)
        after=probe(candidate)
        if abs(after['duration']-info['duration'])>.3:raise ValueError('Captioned duration changed unexpectedly')
        run([ffmpeg,'-v','error','-nostdin','-i',str(candidate),'-f','null','-'])
        with output.open('xb') as dest,candidate.open('rb') as inp:shutil.copyfileobj(inp,dest)
    return {'output':str(output),'decode_verified':True,'caption_cues':len(cues),'style':'neutral white with dark outline','visual_and_word_review':'required','sha256':hashlib.sha256(output.read_bytes()).hexdigest()}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('captions');p.add_argument('output');a=p.parse_args()
    try:print(json.dumps(burn(a.source,a.captions,a.output),indent=2))
    except Exception as e:p.exit(1,str(e)+'\n')
