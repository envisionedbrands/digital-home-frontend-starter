#!/usr/bin/env python3
"""Idempotent local readiness check and path binding. No account changes."""
import hashlib,json,platform,shutil,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
 state=ROOT/'state';state.mkdir(exist_ok=True)
 bound=state/'bound-instructions';bound.mkdir(exist_ok=True)
 for p in (ROOT/'instructions').glob('*.md'):
  (bound/p.name).write_text(p.read_text().replace('{{WORKSPACE}}',str(ROOT)))
 tools={name:bool(shutil.which(name)) for name in ['ffmpeg','ffprobe','whisper-cli','claude','codex','buzz']}
 model_info=json.loads((ROOT/'models/PROVENANCE.json').read_text());model=ROOT/'models'/model_info['file']
 model_ok=model.is_file() and hashlib.sha256(model.read_bytes()).hexdigest()==model_info['sha256']
 report={'platform':platform.system(),'python_supported':sys.version_info>=(3,9),'tools_available':tools,'model_integrity':model_ok,'capabilities':{'supplied_transcript':'requires authenticated agent; no meeting connector required','video_cuts':tools['ffmpeg'] and tools['ffprobe'],'english_transcription':tools['ffmpeg'] and tools['whisper-cli'] and model_ok},'accounts_verified':False,'buzz_import_verified_on_this_installation':False,'client_machine_acceptance':'pending'}
 (state/'local-readiness.json').write_text(json.dumps(report,indent=2))
 print(json.dumps(report,indent=2));return 0 if report['python_supported'] else 1
if __name__=='__main__':raise SystemExit(main())
