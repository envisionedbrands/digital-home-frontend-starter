#!/usr/bin/env python3
"""Verify this private package or fetch its pinned speech model. No credentials required."""
import argparse,hashlib,json,os,tempfile,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def verify():
 manifest=json.loads((ROOT/'SHA256SUMS.json').read_text())
 for name,expected in manifest.items():
  p=(ROOT/name).resolve()
  if not p.is_relative_to(ROOT) or not p.is_file() or digest(p)!=expected:raise ValueError('Package verification failed: '+name)
 return {'package_integrity':'verified','files':len(manifest)}
def model():
 verify();info=json.loads((ROOT/'models/PROVENANCE.json').read_text());dest=ROOT/'models'/info['file']
 if dest.exists():
  if digest(dest)!=info['sha256']:raise ValueError('Existing model differs; preserved for inspection')
  return {'model':'verified','downloaded':False}
 fd,name=tempfile.mkstemp(prefix='.model-',dir=dest.parent);os.close(fd);tmp=Path(name)
 try:
  request=urllib.request.Request(info['url'],headers={'User-Agent':'CoppolaSetup/0.2'})
  with urllib.request.urlopen(request,timeout=90) as source,tmp.open('wb') as target:
   total=0
   while True:
    chunk=source.read(1048576)
    if not chunk:break
    total+=len(chunk)
    if total>info['bytes']:raise ValueError('Unexpected model size')
    target.write(chunk)
  if tmp.stat().st_size!=info['bytes'] or digest(tmp)!=info['sha256']:raise ValueError('Model download did not match the verified release')
  # Exclusive creation preserves another installation's concurrently completed file.
  with dest.open('xb') as target,tmp.open('rb') as source:
   for chunk in iter(lambda:source.read(1048576),b''):target.write(chunk)
 finally:tmp.unlink(missing_ok=True)
 return {'model':'verified','downloaded':True}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['verify','model']);a=p.parse_args()
 try:print(json.dumps(model() if a.action=='model' else verify(),indent=2))
 except Exception as error:p.exit(1,str(error)+'\n')
