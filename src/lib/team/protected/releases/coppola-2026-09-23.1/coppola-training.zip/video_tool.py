#!/usr/bin/env python3
"""Local, non-destructive preview cuts for the Coppola owner workspace."""
import shutil
import argparse, hashlib, json, math, subprocess, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
FFMPEG=shutil.which('ffmpeg') or 'ffmpeg'
FFPROBE=shutil.which('ffprobe') or 'ffprobe'
def run(args):
 return subprocess.run(args,check=True,capture_output=True,text=True,timeout=900)
def probe(source):
 source=Path(source).resolve(strict=True)
 d=json.loads(run([FFPROBE,'-v','error','-show_format','-show_streams','-of','json',str(source)]).stdout)
 return {'duration':float(d['format']['duration']),'streams':[{'type':s['codec_type'],'codec':s['codec_name']} for s in d['streams']]}
def validate(plan,duration):
 ranges=plan.get('keeps')
 if not isinstance(ranges,list) or not 1<=len(ranges)<=100: raise ValueError('Supply 1–100 keep ranges')
 previous=0
 for r in ranges:
  a,b=r.get('start'),r.get('end')
  if any(type(x) not in (int,float) or not math.isfinite(x) for x in [a,b]): raise ValueError('Times must be finite numbers')
  if not 0<=previous<=a<b<=duration: raise ValueError('Ranges must be ordered, nonoverlapping, and inside the source')
  previous=b
 return ranges
def render(source,plan,output):
 source=Path(source).resolve(strict=True); output=Path(output).resolve()
 if not output.is_relative_to((ROOT/'video/results').resolve()): raise ValueError('Output must be within this client video/results folder')
 if output.exists() or output==source: raise ValueError('Will not overwrite a file')
 if output.suffix.lower()!='.mp4': raise ValueError('Output must be MP4')
 info=probe(source); types={s['type'] for s in info['streams']}
 if not {'video','audio'}<=types: raise ValueError('This preview path requires both video and audio')
 ranges=validate(plan,info['duration']); output.parent.mkdir(parents=True,exist_ok=True)
 graph=[]; links=[]
 for i,r in enumerate(ranges):
  a,b=r['start'],r['end']
  graph.extend([f'[0:v]trim=start={a}:end={b},setpts=PTS-STARTPTS[v{i}]',f'[0:a]atrim=start={a}:end={b},asetpts=PTS-STARTPTS[a{i}]'])
  links.append(f'[v{i}][a{i}]')
 graph.append(''.join(links)+f'concat=n={len(ranges)}:v=1:a=1[v][a]')
 with tempfile.TemporaryDirectory(dir=output.parent,prefix='.preview-') as tmp:
  candidate=Path(tmp)/'preview.mp4'
  run([FFMPEG,'-v','error','-nostdin','-i',str(source),'-filter_complex',';'.join(graph),'-map','[v]','-map','[a]','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-movflags','+faststart',str(candidate)])
  verified=probe(candidate)
  expected=sum(r['end']-r['start'] for r in ranges)
  if abs(verified['duration']-expected)>.3: raise ValueError('Preview duration differs from the requested cuts')
  run([FFMPEG,'-v','error','-nostdin','-i',str(candidate),'-f','null','-'])
  # Exclusive create prevents a concurrent render overwriting a result.
  with output.open('xb') as target, candidate.open('rb') as inp:
   import shutil; shutil.copyfileobj(inp,target)
 return {'output':str(output),'duration':verified['duration'],'decode_verified':True,'editorial_review':'pending','sha256':hashlib.sha256(output.read_bytes()).hexdigest()}
if __name__=='__main__':
 p=argparse.ArgumentParser(); sub=p.add_subparsers(dest='cmd',required=True)
 a=sub.add_parser('probe');a.add_argument('source')
 a=sub.add_parser('render');a.add_argument('source');a.add_argument('plan');a.add_argument('output')
 args=p.parse_args()
 try: print(json.dumps(probe(args.source) if args.cmd=='probe' else render(args.source,json.loads(Path(args.plan).read_text()),args.output),indent=2))
 except Exception as e: p.exit(1,str(e)+'\n')
