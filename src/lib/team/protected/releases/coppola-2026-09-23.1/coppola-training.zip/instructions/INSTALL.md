# Coppola installation and repair

The assistant executes these commands from the trusted package folder using its terminal tool. Do not make the owner become a developer. No installation on a greeting. An authorised setup request permits routine setup; honour actual runtime approval prompts.

1. Run `python3 coppola_setup.py check`. This runs tool version probes and checks the model checksum. Read the output, not old memories.
2. If required tools/model are missing and setup is authorised: `python3 coppola_setup.py repair --allow-install`. This reuses working tools, installs only missing Homebrew packages and downloads the pinned model when needed. It does not install Homebrew, change account permissions, repair broken existing binaries or enable a watcher. Tell the owner about the model download once.
3. If Homebrew is absent or a different platform needs setup, identify the OS, use the official Python, FFmpeg, whisper.cpp and rclone install instructions, execute within granted permissions, then rerun check. Never claim an unsupported platform was tested. The current automated installer is verified only on this Mac with existing Homebrew/tools.
4. If burned captions are unavailable in the installed FFmpeg build, report the missing subtitles/libass filter. Do not silently replace a working FFmpeg installation. Use a verified libass-enabled installation after checking its official instructions. Sidecar SRT remains usable.
5. For real footage: probe, transcribe the original to choose meaningful cuts, render a new preview, then transcribe THAT PREVIEW so subtitle timings match the edited video. `python3 transcribe_tool.py /absolute/preview.mp4 /absolute/new-video-results-folder`
6. Inspect the generated transcript and SRT against speech; machine output is a draft. Run `python3 caption_tool.py /absolute/preview.mp4 /absolute/transcript.srt /absolute/new-captioned-preview.mp4`. It refuses overwrites and out-of-range or overlapping cues, uses a neutral readable style, preserves audio and fully decodes the result. View a frame during speech to verify subtitles are visible. Do not call a successful encode an accuracy review.
7. Save evidence in state and report exact completed capabilities separately: cutting, transcription, SRT, burned-caption render, Drive transfer, phone review and watcher. Never infer all from one test. Never say Coppola cannot transcribe merely because video_tool.py does not.

Official installation sources checked 23 September 2026:
- https://formulae.brew.sh/formula/ffmpeg
- https://formulae.brew.sh/formula/whisper.cpp
- https://formulae.brew.sh/formula/rclone
- https://www.python.org/downloads/
- https://ffmpeg.org/download.html
- https://github.com/ggml-org/whisper.cpp
- https://rclone.org/install/

## HyperFrames for composed video and motion
Run `python3 coppola_setup.py check --hyperframes`. After authorised setup, run `python3 coppola_setup.py repair --allow-install --hyperframes`. It checks Node 22+, installs missing Node through existing Homebrew when possible, and installs the pinned HyperFrames package into this workspace's runtime directory instead of replacing a global installation. If existing Node is too old or an existing workspace runtime differs, preserve it and resolve the specific conflict.
Use `runtime/node_modules/.bin/hyperframes` (Windows: the .cmd counterpart) for doctor, check and render. Run doctor and inspect missing browser/FFmpeg findings; use official CLI browser setup only when required. On a first motion task, inspect available HyperFrames training; if absent, use the CLI's supported `skills update general-video` and verify the installed skill files before authoring. Preserve newer or locally customised training; don't overwrite it blindly. Run a tiny generated composition through check and render before declaring motion ready. Basic cuts/transcription need not wait for optional motion tooling.
Official package: https://www.npmjs.com/package/hyperframes
Official source: https://github.com/heygen-com/hyperframes
The tested version is pinned, not claimed to be latest.

Doctor may report optional music/TTS models or Docker unavailable. For local cuts/captions/motion, evaluate required Node, FFmpeg, FFprobe and Chrome checks individually; do not install optional AI models or start Docker solely to turn the overall flag green.
