# Coppola editorial and publishing-pack training

This is original client-neutral training based on the owner's requested outcomes. It does not represent a redistribution or verified import of AI Her Way's proprietary training. The exact earlier hook-source remains unconfirmed; do not say it has been transferred.

## Select the message before editing
Read the actual source transcript and client voice/context. Determine audience, purpose and destination from the brief or existing profile; ask only if missing. Identify a complete useful idea, its supporting evidence and its natural payoff. Preserve caveats and the speaker's meaning. Mark private, withdrawn or sensitive passages as excluded from reuse, not simply cut for pace.

## Present three distinct opening options
Provide three source-grounded hook options for a short-form edit: a clear tension/problem, a concrete useful insight, and a specific surprising observation when the source supports it. These are options, not required formulas; replace an unsupported category with another faithful opening. For each provide exact source quote, verified source start/end, the proposed written hook, relevance to the audience, payoff later in the clip, and a short reason for its ranking. Clearly distinguish exact spoken words from adapted headline copy. Never invent a quote or promise an outcome the clip does not deliver. If supplied transcript has no verified timestamps, quote the passage and mark timing pending; do not fabricate a cut range.

Rank the strongest complete message first, considering specificity, clarity, relevance and whether the clip delivers on its opening. Avoid sensationalism, unsupported numerical claims and misleading removal of qualifiers. Propose the best option and allow the owner to choose. Only reorder speech when technically supported by the edit plan and explicitly requested/approved; ascending-cut helper does not implement reordered hooks. Written hook options do not mean three alternative video renders exist.

## Shape and verify the edit
Preserve full word boundaries, thoughtful pauses, natural breaths and context. Remove repetition only if meaning stays intact. Save a versioned source-referenced edit plan, render a review copy, transcribe the edited result for aligned caption timings, and inspect actual frames/audio. Apply the owner's approved video brand profile. A demo style remains a proposed style until selected.

## Deliver useful companion assets
For each reviewed video, produce a readable edited transcript, sidecar subtitles when transcribed, the three hook options, a suggested title, destination-specific post text for the agreed platforms, and a concise review note. A short derivative needs its own source mapping and companion assets. Use the client's voice and permission boundaries; do not add fabricated calls to action or offers. Tie companion files to the exact video version and source, invalidate them after relevant edits, and preserve previous versions.

## Approval and automation are separate
Draft copy, a rendered preview, client-approved video, client-approved copy and actual publication are distinct states. Deliver files and links through the current private client conversation; never publish or send externally without the owner's request. These are agent-executed steps for an authorised job, not evidence of an installed autonomous watcher.

## Preserved existing Coppola editorial training
The prior MIT-licensed transcript-first selection and editorial ledger are included in instructions/editorial-reference/. Read them for source-grounded shortlisting, full context, alternatives and review evidence. Their older machine edit schema and run command belong to a separate editor and are NOT implemented by this package. Use the current helpers and their documented contracts. Segment SRT is not word alignment; do not fabricate word IDs or apply precision cuts without verified word boundaries. The existing reference is Coppola training, not proof of the exact AI Her Way addition requested.
