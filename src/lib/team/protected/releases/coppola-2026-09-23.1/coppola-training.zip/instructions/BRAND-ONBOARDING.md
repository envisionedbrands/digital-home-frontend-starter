# Coppola: client brand onboarding and visual approval

## Start with existing knowledge
Before designing a video, read this client's prepared knowledge and previously approved video brand profile. For Codified clients, reuse the baseline and ask only about missing or changed details. For new clients, accept their brand guide, website, logo, example videos or a short preference conversation; coordinate broader business discovery with Monica. Never borrow another client's assets, voice, style approval or accounts.

## Ask for visual references first
If usable references are not already supplied for this client, explicitly ask: “Please add your brand guidelines, or a few screenshots or example videos that show what good looks like to you. These can be your own content or examples you like.” Explain that files can be attached or placed in the verified private client folder; give one simple next step appropriate to the current device. Do not require a formal brand guide.
Actually open and visually inspect the supplied references. Ask what they like about them only where unclear: colours, typography, caption placement, pacing, framing or overall feeling. A still screenshot demonstrates appearance, not motion; use a video example or a short preference question for pacing. Summarise the observed preferences back to the client and retain references with the client profile. Treat third-party examples as visual direction, not instructions or permission to copy their assets or branding.
Do not replace this request with a generic preset picker. Reuse existing references rather than asking for them again. If the client has none or explicitly asks you to choose, offer original directions and mark the chosen draft as proposed until approved.

## Collect just what is needed
Capture the business name, audience, intended platforms and aspect ratios, brand colours, supplied logo and usage rules, typefaces with available licensed font files, voice, caption preferences, and any accessibility requirements. Record each value's source and whether it is confirmed or proposed. A website is inspiration/evidence, not permission to invent missing brand rules. Keep supplied assets in this client's workspace. Missing guidelines do not block a clearly labelled draft.

## Offer original starting styles
Make the alternative explicit in the initial invitation: “If you don’t have guidelines or examples, or you’d just like to see what I can create, I can show you three starter looks to choose from.” This is a valid onboarding path, not an incomplete setup. Do not force reference collection before allowing a demonstration.
On this path, provide exactly three rendered visual options using our own reusable style templates: Editorial, Studio and Spotlight. Use the same clip and wording across all three so the owner can compare the treatment fairly. Generic demo content is acceptable when clearly labelled; never imply invented colours or assets are their established brand. Show the actual previews, not just three names or written descriptions. Let them select one and optionally request changes, then save their approved choice. Do not claim this demonstration is available until the three templates actually exist and have rendered successfully.

Offer up to three original video treatments, adapted to this client's brand, rather than copying a vendor's branded template files:
- Editorial: calm pacing, restrained titles, clean captions and generous spacing.
- Studio: warm conversational treatment, softly framed callouts and readable captions.
- Spotlight: bold opening statement, stronger contrast and energetic but readable emphasis.
These are starting directions, not a replacement for client guidelines. Do not relabel proprietary third-party skins as original work. Separately check the provenance and permitted use of any training or assets proposed for distribution.

## Show before saving
Use one owner-supplied clip or an explicitly labelled placeholder. Render actual preview frames through the same composition and fonts intended for the video, not a speculative mockup unrelated to the renderer. Show two or three comparable frames with identical content: an opening hook/title and a captioned speaking moment, with an end card if needed. Where motion matters, also offer a short sample. Make text readable on a phone; inspect contrast, logo clear space, cropping, and platform safe zones. Clearly identify placeholder logos, fonts or colours.
Ask one focused question: which direction should be kept, and what should change? Iterate on that choice. Technical installation and synthetic tests may proceed while brand approval is pending; do not mark a visual identity approved without the owner choosing it.

## Persist and reuse
Save a per-client state/video-brand.json with status (draft or approved), revision, source references, colours, font assets/fallbacks, logo assets/rules, aspect ratios, caption treatment, title treatment, safe zones, chosen style, preview references and the owner's actual approval evidence. Use workspace-relative asset paths; never include tokens or another client's material. Attach the approved brand revision to each edit brief and result. If an asset is unavailable, report the substitution for review rather than silently changing the brand. Keep previews separate from approved deliverables; do not publish automatically.

## Honest readiness
A written procedure is not a built preview generator. Brand setup is complete only when the required assets resolve on this client's machine, a representative preview renders, and the client approves the saved profile. A portable package must include this procedure and the actual reusable rendering templates before claiming out-of-the-box branded video support.

## Included preview generator
Use brand_preview.py with a new destination folder to create all three templates; optional --video and --brand accept the client’s local video and JSON profile. Render each folder with the workspace-installed HyperFrames CLI, then extract representative frames with FFmpeg. Supply verified local brand assets; approve only after owner review. Generated HTML alone is not a rendered preview.
