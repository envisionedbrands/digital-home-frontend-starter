# Editorial ledger contract

Create `editorial-review.md` in the client project input folder before rendering. Include:

- client/project, source filename + SHA-256, brand source locator + version/hash, language, objective, platform, duration target;
- context summary and known transcript limitations;
- shortlist table: moment ID | SOURCE in/out | exact quote + word IDs | before/after context | audience situation/value | positioning/offer/voice evidence | hook/proof/payoff | risk/confidence | proposed decision;
- alternative openings and excluded strong moments with reasons;
- protected pauses/gestures and cut decisions, each source-timecoded;
- approval receipt and all unresolved questions.

The machine edit `moments` array requires `id`, `source_start_ms`, `source_end_ms`, `word_ids`, `quote`, `context`, `brand_relevance`, `audience_value`, `reason`, `confidence`, `approval`. Use full verbatim words in original order for the quoted interval; do not skip a negation. The helper checks IDs, text and bounds, not semantic honesty. Optional added fields may include `brand_evidence_refs`, `hook`, `payoff`, `risk`, `alternatives`, `approved_event_id`.

A source interval alone is not a final edit. `keeps_ms` is the authoritative output selection, and it can contain several smaller clips from an approved moment. Explain every shortening in the human ledger. Every clip must be traceable to a selected moment or a labeled contextual bridge. The reviewer must check this; JSON presence is not evidence of good judgment.

Use a recommendation such as “Keep 00:02:14.400–00:02:39.200: exact quote…; relevant because…; preserve the qualification at…”, never “This will go viral.” Do not fabricate a real example. The only runnable example in this package is explicitly synthetic.
