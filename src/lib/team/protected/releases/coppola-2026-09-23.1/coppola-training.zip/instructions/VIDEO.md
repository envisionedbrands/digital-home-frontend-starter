The included local helper uses installed ffmpeg/ffprobe. It validates source time ranges, preserves the source, renders a new H.264/AAC preview, probes it, and fully decodes it before reporting completion. It supports ordinary cuts on files with video and audio. That cutting helper does not transcribe or caption. Use the separate transcribe_tool.py and caption_tool.py for those tasks; see INSTALL.md. It does not add brand graphics, host previews, or publish.

Usage:
`python3 video_tool.py probe /absolute/input.mp4`
`python3 video_tool.py render /absolute/input.mp4 /absolute/plan.json /absolute/new-output.mp4`

Plan: {"keeps": [{"start": 0.0, "end": 10.0}]}
Cuts must be ascending, nonoverlapping and within the measured source duration. Output must be new and within this package's video/results directory.

## Local audio transcription — tested installation path
A local CPU transcription helper is now available at this package root: transcribe_tool.py. Run `python3 transcribe_tool.py /absolute/source /absolute/new-results-folder`. It accepts audio/video, extracts mono audio and produces machine-draft transcript.txt plus transcript.srt with provenance. It uses the English model verified under models/ (downloaded during setup if missing), makes no network call, and refuses to overwrite existing results. Do not infer speaker identities; review names, numbers and timestamps. It does not burn subtitles into a video. If a dependency is missing, follow ONBOARDING.md; never claim transcription worked without output verification.

For the complete current setup and caption workflow, follow instructions/INSTALL.md. Transcribe the edited preview before burning captions so timestamps match the cuts.

For hook selection and companion assets read instructions/EDITORIAL.md. For client brand setup and the three original preview styles read instructions/BRAND-ONBOARDING.md.
