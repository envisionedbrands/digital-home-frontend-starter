#!/usr/bin/env python3
"""Create three original HyperFrames brand previews using local client assets."""
import argparse,html,json,re,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def build(destination, title, caption, video=None, brand=None):
 destination=Path(destination).resolve()
 if destination.exists(): raise ValueError('Use a new preview folder; existing work is preserved')
 styles=json.loads((ROOT/'templates/video-styles.json').read_text())
 profile=json.loads(Path(brand).read_text()) if brand else {}
 for key in ('background','ink','accent','panel'):
  if key in profile and not re.fullmatch(r'#[0-9a-fA-F]{6}',profile[key]):raise ValueError('Brand colours must be six-digit hex values')
 if len(title)>110 or len(caption)>150: raise ValueError('Keep preview title under 110 and caption under 150 characters')
 if video and not Path(video).is_file():raise ValueError('Supplied video is missing')
 destination.mkdir(parents=True)
 for name,defaults in styles.items():
  s={**defaults,**{k:v for k,v in profile.items() if k in ('background','ink','accent','panel')}}
  folder=destination/name;folder.mkdir();assets=folder/'assets';assets.mkdir()
  label=html.escape(profile.get('business_name','YOUR BRAND'))
  media='<div class="placeholder">Your footage here<span>STYLE DEMO · NO CLIENT FOOTAGE</span></div>'
  if video:
   ext=Path(video).suffix;shutil.copy2(video,assets/('source'+ext));media=f'<video class="footage" src="assets/source{ext}" data-start="0" data-duration="3" data-track-index="0" muted></video>'
  logo=''
  if profile.get('logo'):
   logo_path=(Path(brand).resolve().parent/profile['logo']).resolve()
   if logo_path.suffix.lower() not in ('.png','.jpg','.jpeg','.webp'):raise ValueError('Supply a local PNG, JPEG or WebP logo')
   shutil.copy2(logo_path,assets/('logo'+logo_path.suffix));logo=f'<img class="logo" src="assets/logo{logo_path.suffix}" alt="Brand logo">'
  doc='''<!doctype html><html><head><meta charset="utf-8"><style>*{box-sizing:border-box}html,body{margin:0;width:540px;height:960px;background:BG;color:INK;font-family:sans-serif}#root{position:relative;width:100%;height:100%;overflow:hidden}.top{position:absolute;top:65px;left:40px;right:40px;font-size:16px;letter-spacing:3px;display:flex;justify-content:space-between;align-items:center}.logo{max-width:110px;max-height:45px;object-fit:contain}h1{position:absolute;top:135px;left:40px;right:40px;margin:0;font-size:47px;line-height:1.08;letter-spacing:-1.6px}.visual{position:absolute;left:40px;right:40px;top:350px;height:335px;border-radius:RADIUSpx;overflow:hidden;background:PANEL}.placeholder{height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:29px;color:INK;background:linear-gradient(140deg,PANEL,BG)}.placeholder:before{content:'▶';color:ACCENT;font-size:58px;margin-bottom:20px}.placeholder span{font-size:11px;letter-spacing:2px;margin-top:18px}.footage{width:100%;height:100%;object-fit:cover}.caption{position:absolute;top:720px;left:40px;right:40px;padding:22px;border-left:5px solid ACCENT;background:PANEL;font-size:26px;line-height:1.3;border-radius:RADIUSpx}.footer{position:absolute;left:40px;right:40px;bottom:52px;font-size:13px;letter-spacing:2px;color:INK}.rule{position:absolute;left:40px;top:310px;width:75px;height:5px;background:ACCENT}STYLE</style></head><body><div id="root" data-composition-id="main" data-no-timeline data-start="0" data-duration="3" data-width="540" data-height="960"><div class="top">LABELLOGO</div><h1>TITLE</h1><div class="rule"></div><div class="visual">MEDIA</div><div class="caption">CAPTION</div><div class="footer">NAME · PROPOSED LOOK</div></div></body></html>'''
  extra={'editorial':'h1{font-family:serif;font-weight:400}.caption{background:transparent;padding-left:18px}', 'studio':'h1{font-weight:600}.visual{box-shadow:0 15px 40px #93554615}.caption{border:0;text-align:center}', 'spotlight':'h1{font-weight:900;text-transform:uppercase;font-size:45px}.caption{color:#121727;background:ACCENT;font-weight:700;border:0}' }[name]
  for key,value in [('STYLE',extra),('BG',s['background']),('INK',s['ink']),('ACCENT',s['accent']),('PANEL',s['panel']),('RADIUS',str(s['radius'])),('LABEL',label),('LOGO',logo),('TITLE',html.escape(title)),('CAPTION',html.escape(caption)),('MEDIA',media),('NAME',name.upper())]:doc=doc.replace(key,value)
  (folder/'index.html').write_text(doc)
  (folder/'hyperframes.json').write_text(json.dumps({'paths':{'assets':'assets'},'authoringSkill':'general-video'}))
 (destination/'preview-receipt.json').write_text(json.dumps({'status':'compositions_created_not_rendered','styles':list(styles),'brand_approved':False,'source':'client_video' if video else 'labelled_placeholder'},indent=2))
 return {'compositions':[str(destination/name) for name in styles],'next':'Render each composition with the installed HyperFrames CLI and inspect frames before showing the client.'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('destination');p.add_argument('--title',default='Your best ideas deserve to be seen.');p.add_argument('--caption',default='Make room for the message that matters.');p.add_argument('--video');p.add_argument('--brand');a=p.parse_args()
 try:print(json.dumps(build(a.destination,a.title,a.caption,a.video,a.brand),indent=2))
 except Exception as e:p.exit(1,str(e)+'\n')
